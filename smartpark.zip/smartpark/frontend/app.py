import streamlit as st
import requests
import pandas as pd

API_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="SmartPark",
    page_icon="🚗",
    layout="wide"
)


# -----------------------------
# Session State
# -----------------------------

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "token" not in st.session_state:
    st.session_state.token = None

if "page" not in st.session_state:
    st.session_state.page = "Home"


# -----------------------------
# API Helper
# -----------------------------

def api_request(method, endpoint, **kwargs):
    try:
        return requests.request(
            method,
            f"{API_URL}{endpoint}",
            timeout=10,
            **kwargs
        )
    except requests.exceptions.RequestException as e:
        st.error(f"Backend connection error: {e}")
        return None


# -----------------------------
# Landing Page
# -----------------------------

def landing_page():

    st.title("🚗 SmartPark")

    st.subheader(
        "Smart Parking Garage Management System"
    )

    st.write(
        "Manage parking spaces, check vehicles in and out, "
        "calculate accurate parking fees, and monitor EV "
        "availability from one simple dashboard."
    )

    st.divider()

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("### 🚘 Fast Check-in")
        st.write(
            "Assign suitable parking spots quickly "
            "when vehicles arrive."
        )

    with col2:
        st.markdown("### 💰 Accurate Billing")
        st.write(
            "Automatically calculate tiered parking fees "
            "with hourly rounding and daily caps."
        )

    with col3:
        st.markdown("### ⚡ EV Management")
        st.write(
            "Ensure EV vehicles are assigned only to "
            "EV charging spots."
        )

    st.divider()

    st.markdown("## Who is SmartPark for?")

    st.write(
        "SmartPark is designed for parking attendants and "
        "garage operators who need a reliable way to manage "
        "vehicles and limited parking capacity."
    )

    st.markdown("## How it helps")

    st.write(
        "The system prevents duplicate active parking sessions, "
        "avoids assigning incompatible spots, automatically "
        "calculates fees, and makes vehicle records easy to search."
    )

    st.divider()

    st.markdown("## 🚀 Features we would build next")

    st.write("1. Online payment integration")
    st.write("2. Mobile application for attendants")
    st.write("3. Parking analytics and revenue reports")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        if st.button(
            "🔐 Login",
            use_container_width=True
        ):
            st.session_state.page = "Login"
            st.rerun()

    with col2:
        if st.button(
            "📝 Register",
            use_container_width=True
        ):
            st.session_state.page = "Register"
            st.rerun()


# -----------------------------
# Register
# -----------------------------

def register_page():

    st.title("📝 Create Account")

    name = st.text_input("Name")
    email = st.text_input("Email")
    password = st.text_input(
        "Password",
        type="password"
    )

    if st.button(
        "Register",
        type="primary",
        use_container_width=True
    ):

        if not name or not email or not password:
            st.warning("Please fill all fields.")
            return

        response = api_request(
            "POST",
            "/api/auth/register",
            json={
                "name": name,
                "email": email,
                "password": password
            }
        )

        if response is not None:

            if response.status_code == 200:
                st.success(
                    "Registration successful!"
                )
                st.session_state.page = "Login"
                st.rerun()

            else:
                try:
                    st.error(response.json()["detail"])
                except Exception:
                    st.error("Registration failed.")

    if st.button("← Back"):
        st.session_state.page = "Home"
        st.rerun()


# -----------------------------
# Login
# -----------------------------

def login_page():

    st.title("🔐 Login")

    email = st.text_input("Email")
    password = st.text_input(
        "Password",
        type="password"
    )

    if st.button(
        "Login",
        type="primary",
        use_container_width=True
    ):

        response = api_request(
            "POST",
            "/api/auth/login",
            json={
                "email": email,
                "password": password
            }
        )

        if response is not None:

            if response.status_code == 200:

                data = response.json()

                st.session_state.token = data[
                    "access_token"
                ]

                st.session_state.logged_in = True
                st.session_state.page = "Dashboard"

                st.rerun()

            else:
                try:
                    st.error(response.json()["detail"])
                except Exception:
                    st.error("Login failed.")

    if st.button("← Back"):
        st.session_state.page = "Home"
        st.rerun()


# -----------------------------
# Dashboard
# -----------------------------

def dashboard():

    st.title("🚗 SmartPark Dashboard")

    response = api_request(
        "GET",
        "/api/garages"
    )

    if response is None:
        return

    if response.status_code != 200:
        st.error("Unable to load garages.")
        return

    garages = response.json()

    if not garages:
        st.warning("No garage configured.")
        return

    garage = garages[0]
    garage_id = garage["id"]

    response = api_request(
        "GET",
        f"/api/parking/availability?garage_id={garage_id}"
    )

    if response is None:
        return

    availability = response.json()

    total = availability["total"]
    available = availability["available"]
    occupied = availability["occupied"]

    ev_response = api_request(
        "GET",
        f"/api/parking/availability"
        f"?garage_id={garage_id}&spot_type=EV"
    )

    ev_data = ev_response.json()

    ev_available = ev_data["available"]
    ev_total = ev_data["total"]

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Total Spots",
        total
    )

    col2.metric(
        "Available",
        available
    )

    col3.metric(
        "Occupied",
        occupied
    )

    col4.metric(
        "⚡ EV Available",
        f"{ev_available}/{ev_total}"
    )

    st.divider()

    st.markdown("### Quick Actions")

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button(
            "🚘 Check In",
            use_container_width=True
        ):
            st.session_state.page = "Check In"
            st.rerun()

    with col2:
        if st.button(
            "🚪 Check Out",
            use_container_width=True
        ):
            st.session_state.page = "Check Out"
            st.rerun()

    with col3:
        if st.button(
            "🔎 Search Vehicle",
            use_container_width=True
        ):
            st.session_state.page = "Search"
            st.rerun()

    st.divider()

    st.markdown("### Parking Overview")

    spots = availability["spots"]

    df = pd.DataFrame(spots)

    if not df.empty:

        df["status"] = df["available"].apply(
            lambda x: "🟢 Available"
            if x else "🔴 Occupied"
        )

        st.dataframe(
            df[
                [
                    "level",
                    "spot_number",
                    "spot_type",
                    "status"
                ]
            ],
            use_container_width=True,
            hide_index=True
        )


# -----------------------------
# Check In
# -----------------------------

def check_in():

    st.title("🚘 Vehicle Check-in")

    garages_response = api_request(
        "GET",
        "/api/garages"
    )

    if garages_response is None:
        return

    garages = garages_response.json()

    if not garages:
        st.error("No garage available.")
        return

    garage_options = {
        garage["name"]: garage["id"]
        for garage in garages
    }

    selected_garage = st.selectbox(
        "Garage",
        list(garage_options.keys())
    )

    license_plate = st.text_input(
        "License Plate",
        placeholder="RJ14AB1234"
    )

    vehicle_type = st.selectbox(
        "Vehicle Type",
        [
            "COMPACT",
            "STANDARD",
            "EV"
        ]
    )

    if st.button(
        "🚘 Check In Vehicle",
        type="primary"
    ):

        if not license_plate:
            st.warning(
                "Please enter license plate."
            )
            return

        response = api_request(
            "POST",
            "/api/parking/check-in",
            json={
                "garage_id":
                    garage_options[selected_garage],

                "license_plate":
                    license_plate,

                "vehicle_type":
                    vehicle_type
            }
        )

        if response is None:
            return

        if response.status_code == 200:

            data = response.json()

            st.success(
                "Vehicle checked in successfully!"
            )

            st.info(
                f"Assigned Spot: **{data['spot']}**\n\n"
                f"Spot Type: **{data['spot_type']}**"
            )

        else:

            try:
                st.error(
                    response.json()["detail"]
                )
            except Exception:
                st.error("Check-in failed.")


# -----------------------------
# Check Out
# -----------------------------

def check_out():

    st.title("🚪 Vehicle Check-out")

    license_plate = st.text_input(
        "License Plate",
        placeholder="RJ14AB1234"
    )

    if st.button(
        "🚪 Check Out",
        type="primary"
    ):

        if not license_plate:
            st.warning(
                "Enter a license plate."
            )
            return

        response = api_request(
            "POST",
            "/api/parking/check-out",
            json={
                "license_plate":
                    license_plate
            }
        )

        if response is None:
            return

        if response.status_code == 200:

            data = response.json()

            st.success(
                "Vehicle checked out successfully!"
            )

            col1, col2, col3 = st.columns(3)

            col1.metric(
                "Parking Spot",
                data["spot"]
            )

            col2.metric(
                "Billable Hours",
                data["billable_hours"]
            )

            col3.metric(
                "Total Fee",
                f"₹{data['fee']:.2f}"
            )

        else:

            try:
                st.error(
                    response.json()["detail"]
                )
            except Exception:
                st.error("Check-out failed.")


# -----------------------------
# Search
# -----------------------------

def search_vehicle():

    st.title("🔎 Search Parking Records")

    search = st.text_input(
        "Search by License Plate",
        placeholder="RJ14"
    )

    col1, col2, col3 = st.columns(3)

    with col1:
        page = st.number_input(
            "Page",
            min_value=1,
            value=1
        )

    with col2:
        limit = st.selectbox(
            "Records per page",
            [5, 10, 20]
        )

    with col3:
        sort_by = st.selectbox(
            "Sort By",
            [
                "check_in",
                "check_out",
                "fee",
                "license_plate",
                "status"
            ]
        )

    order = st.radio(
        "Order",
        ["desc", "asc"],
        horizontal=True
    )

    if st.button(
        "🔎 Search",
        type="primary"
    ):

        endpoint = (
            f"/api/parking/sessions"
            f"?page={page}"
            f"&limit={limit}"
            f"&search={search}"
            f"&sort_by={sort_by}"
            f"&order={order}"
        )

        response = api_request(
            "GET",
            endpoint
        )

        if response is None:
            return

        if response.status_code != 200:
            st.error(
                "Unable to retrieve records."
            )
            return

        data = response.json()

        st.write(
            f"Showing page {data['page']} "
            f"of {data['pages']} "
            f"({data['total']} total records)"
        )

        records = data["data"]

        if records:

            display_data = []

            for item in records:

                display_data.append({
                    "Plate":
                        item["license_plate"],

                    "Vehicle":
                        item["vehicle_type"],

                    "Spot":
                        item["spot_id"],

                    "Check-in":
                        item["check_in"],

                    "Check-out":
                        item["check_out"],

                    "Fee":
                        item["fee"],

                    "Status":
                        item["status"]
                })

            st.dataframe(
                pd.DataFrame(display_data),
                use_container_width=True,
                hide_index=True
            )

        else:
            st.info(
                "No parking records found."
            )


# -----------------------------
# Navigation
# -----------------------------

if not st.session_state.logged_in:

    if st.session_state.page == "Register":
        register_page()

    elif st.session_state.page == "Login":
        login_page()

    else:
        landing_page()

else:

    with st.sidebar:

        st.title("🚗 SmartPark")

        if st.button(
            "📊 Dashboard",
            use_container_width=True
        ):
            st.session_state.page = "Dashboard"
            st.rerun()

        if st.button(
            "🚘 Check In",
            use_container_width=True
        ):
            st.session_state.page = "Check In"
            st.rerun()

        if st.button(
            "🚪 Check Out",
            use_container_width=True
        ):
            st.session_state.page = "Check Out"
            st.rerun()

        if st.button(
            "🔎 Search",
            use_container_width=True
        ):
            st.session_state.page = "Search"
            st.rerun()

        st.divider()

        if st.button(
            "Logout",
            use_container_width=True
        ):
            st.session_state.logged_in = False
            st.session_state.token = None
            st.session_state.page = "Home"
            st.rerun()

    if st.session_state.page == "Dashboard":
        dashboard()

    elif st.session_state.page == "Check In":
        check_in()

    elif st.session_state.page == "Check Out":
        check_out()

    elif st.session_state.page == "Search":
        search_vehicle()

    else:
        dashboard()