from datetime import datetime
from pydantic import BaseModel, EmailStr


class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class GarageCreate(BaseModel):
    name: str
    address: str = ""
    first_hour_rate: float = 50
    additional_hour_rate: float = 30
    daily_cap: float = 300


class SpotCreate(BaseModel):
    level: int
    spot_number: str
    spot_type: str


class CheckInRequest(BaseModel):
    garage_id: int
    license_plate: str
    vehicle_type: str


class CheckOutRequest(BaseModel):
    license_plate: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str