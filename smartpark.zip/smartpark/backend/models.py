from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    DateTime,
    ForeignKey
)
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Garage(Base):
    __tablename__ = "garages"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    address = Column(String)
    first_hour_rate = Column(Float, default=50)
    additional_hour_rate = Column(Float, default=30)
    daily_cap = Column(Float, default=300)

    spots = relationship(
        "ParkingSpot",
        back_populates="garage",
        cascade="all, delete-orphan"
    )


class ParkingSpot(Base):
    __tablename__ = "parking_spots"

    id = Column(Integer, primary_key=True, index=True)
    garage_id = Column(Integer, ForeignKey("garages.id"))
    level = Column(Integer, nullable=False)
    spot_number = Column(String, nullable=False)
    spot_type = Column(String, nullable=False)
    is_occupied = Column(Boolean, default=False)

    garage = relationship(
        "Garage",
        back_populates="spots"
    )


class ParkingSession(Base):
    __tablename__ = "parking_sessions"

    id = Column(Integer, primary_key=True, index=True)
    garage_id = Column(Integer, ForeignKey("garages.id"))
    spot_id = Column(Integer, ForeignKey("parking_spots.id"))

    license_plate = Column(String, index=True, nullable=False)
    vehicle_type = Column(String, nullable=False)

    check_in = Column(DateTime, default=datetime.utcnow)
    check_out = Column(DateTime, nullable=True)

    fee = Column(Float, nullable=True)
    status = Column(String, default="PARKED")