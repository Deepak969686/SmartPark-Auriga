import math
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import ParkingSpot, ParkingSession, Garage
from ..schemas import CheckInRequest, CheckOutRequest

router = APIRouter(
    prefix="/api/parking",
    tags=["Parking"]
)


def calculate_fee(
    check_in: datetime,
    check_out: datetime,
    first_hour_rate: float,
    additional_hour_rate: float,
    daily_cap: float
):
    duration_seconds = (
        check_out - check_in
    ).total_seconds()

    hours = max(
        1,
        math.ceil(duration_seconds / 3600)
    )

    if hours == 1:
        fee = first_hour_rate
    else:
        fee = (
            first_hour_rate
            + (hours - 1) * additional_hour_rate
        )

    # Apply daily cap for each 24-hour period.
    days = math.ceil(hours / 24)

    fee = min(
        fee,
        days * daily_cap
    )

    return round(fee, 2), hours


@router.post("/check-in")
def check_in(
    data: CheckInRequest,
    db: Session = Depends(get_db)
):
    garage = db.query(Garage).filter(
        Garage.id == data.garage_id
    ).first()

    if not garage:
        raise HTTPException(
            status_code=404,
            detail="Garage not found"
        )

    plate = data.license_plate.strip().upper()
    vehicle_type = data.vehicle_type.strip().upper()

    existing = db.query(ParkingSession).filter(
        ParkingSession.license_plate == plate,
        ParkingSession.status == "PARKED"
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="Vehicle is already parked"
        )

    if vehicle_type not in {
        "COMPACT",
        "STANDARD",
        "EV"
    }:
        raise HTTPException(
            status_code=400,
            detail="Invalid vehicle type"
        )

    # EV must use EV spot.
    if vehicle_type == "EV":
        allowed_types = ["EV"]
    elif vehicle_type == "STANDARD":
        allowed_types = ["STANDARD"]
    else:
        allowed_types = ["COMPACT", "STANDARD"]

    spot = db.query(ParkingSpot).filter(
        ParkingSpot.garage_id == data.garage_id,
        ParkingSpot.spot_type.in_(allowed_types),
        ParkingSpot.is_occupied == False
    ).first()

    if not spot:
        raise HTTPException(
            status_code=409,
            detail="No suitable parking spot available"
        )

    spot.is_occupied = True

    session = ParkingSession(
        garage_id=data.garage_id,
        spot_id=spot.id,
        license_plate=plate,
        vehicle_type=vehicle_type,
        check_in=datetime.utcnow(),
        status="PARKED"
    )

    db.add(session)
    db.commit()
    db.refresh(session)

    return {
        "message": "Vehicle checked in successfully",
        "session_id": session.id,
        "license_plate": plate,
        "spot": spot.spot_number,
        "spot_type": spot.spot_type,
        "check_in": session.check_in
    }


@router.post("/check-out")
def check_out(
    data: CheckOutRequest,
    db: Session = Depends(get_db)
):
    plate = data.license_plate.strip().upper()

    session = db.query(ParkingSession).filter(
        ParkingSession.license_plate == plate,
        ParkingSession.status == "PARKED"
    ).first()

    if not session:
        raise HTTPException(
            status_code=404,
            detail="Active parking session not found"
        )

    garage = db.query(Garage).filter(
        Garage.id == session.garage_id
    ).first()

    spot = db.query(ParkingSpot).filter(
        ParkingSpot.id == session.spot_id
    ).first()

    check_out_time = datetime.utcnow()

    fee, billable_hours = calculate_fee(
        session.check_in,
        check_out_time,
        garage.first_hour_rate,
        garage.additional_hour_rate,
        garage.daily_cap
    )

    session.check_out = check_out_time
    session.fee = fee
    session.status = "COMPLETED"

    spot.is_occupied = False

    db.commit()

    return {
        "message": "Vehicle checked out successfully",
        "license_plate": plate,
        "spot": spot.spot_number,
        "billable_hours": billable_hours,
        "fee": fee,
        "check_out": check_out_time
    }


@router.get("/search")
def search_vehicle(
    plate: str,
    db: Session = Depends(get_db)
):
    sessions = db.query(ParkingSession).filter(
        ParkingSession.license_plate.contains(
            plate.strip().upper()
        )
    ).all()

    return sessions


@router.get("/sessions")
def get_sessions(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    search: str = "",
    sort_by: str = "check_in",
    order: str = "desc",
    db: Session = Depends(get_db)
):
    query = db.query(ParkingSession)

    if search:
        query = query.filter(
            ParkingSession.license_plate.contains(
                search.strip().upper()
            )
        )

    allowed_sort_fields = {
        "check_in": ParkingSession.check_in,
        "check_out": ParkingSession.check_out,
        "fee": ParkingSession.fee,
        "license_plate": ParkingSession.license_plate,
        "status": ParkingSession.status
    }

    sort_column = allowed_sort_fields.get(
        sort_by,
        ParkingSession.check_in
    )

    if order.lower() == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    total = query.count()

    sessions = query.offset(
        (page - 1) * limit
    ).limit(limit).all()

    return {
        "page": page,
        "limit": limit,
        "total": total,
        "pages": math.ceil(total / limit) if total else 0,
        "data": sessions
    }


@router.get("/availability")
def availability(
    garage_id: int,
    spot_type: str | None = None,
    db: Session = Depends(get_db)
):
    query = db.query(ParkingSpot).filter(
        ParkingSpot.garage_id == garage_id
    )

    if spot_type:
        query = query.filter(
            ParkingSpot.spot_type == spot_type.upper()
        )

    spots = query.all()

    return {
        "total": len(spots),
        "available": sum(
            not spot.is_occupied
            for spot in spots
        ),
        "occupied": sum(
            spot.is_occupied
            for spot in spots
        ),
        "spots": [
            {
                "id": spot.id,
                "level": spot.level,
                "spot_number": spot.spot_number,
                "spot_type": spot.spot_type,
                "available": not spot.is_occupied
            }
            for spot in spots
        ]
    }