import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

const API = "http://127.0.0.1:8000";

function App() {
  const [page, setPage] = useState("landing");
  const [loggedIn, setLoggedIn] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const [garage, setGarage] = useState(null);
  const [spots, setSpots] = useState([]);

  const [plate, setPlate] = useState("");
  const [vehicleType, setVehicleType] = useState("STANDARD");

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const [checkoutResult, setCheckoutResult] = useState(null);

  const [records, setRecords] = useState([]);
  const [recordPage, setRecordPage] = useState(1);
  const [recordPages, setRecordPages] = useState(1);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("check_in");
  const [order, setOrder] = useState("desc");

  useEffect(() => {
    if (loggedIn) {
      loadDashboard();
    }
  }, [loggedIn]);

  const clearMessages = () => {
    setMessage("");
    setError("");
  };

  // -----------------------------
  // Dashboard data
  // -----------------------------

  const loadDashboard = async () => {
    try {
      const response = await axios.get(`${API}/api/garages`);
      const garages = response.data;

      if (!garages.length) {
        setError("No garage configured.");
        return;
      }

      const selectedGarage = garages[0];
      setGarage(selectedGarage);

      const spotsResponse = await axios.get(
        `${API}/api/garages/${selectedGarage.id}/spots`
      );

      setSpots(spotsResponse.data);
    } catch (err) {
      setError("Unable to connect to SmartPark server.");
    }
  };

  // -----------------------------
  // Authentication
  // -----------------------------

  const login = async () => {
    clearMessages();

    try {
      const response = await axios.post(
        `${API}/api/auth/login`,
        {
          email,
          password,
        }
      );

      localStorage.setItem(
        "smartpark_token",
        response.data.access_token
      );

      setLoggedIn(true);
      setPage("dashboard");
    } catch (err) {
      setError(
        err.response?.data?.detail ||
          "Invalid email or password."
      );
    }
  };

  const register = async () => {
    clearMessages();

    if (!name || !email || !password) {
      setError("Please fill all fields.");
      return;
    }

    try {
      await axios.post(
        `${API}/api/auth/register`,
        {
          name,
          email,
          password,
        }
      );

      setMessage(
        "Account created successfully. Please sign in."
      );

      setName("");
      setEmail("");
      setPassword("");

      setTimeout(() => {
        setPage("login");
        setMessage("");
      }, 1000);
    } catch (err) {
      setError(
        err.response?.data?.detail ||
          "Registration failed."
      );
    }
  };

  const logout = () => {
    localStorage.removeItem("smartpark_token");

    setLoggedIn(false);
    setPage("landing");

    clearMessages();
  };

  // -----------------------------
  // Check In
  // -----------------------------

  const checkIn = async () => {
    clearMessages();

    if (!garage) {
      setError("Garage information is unavailable.");
      return;
    }

    if (!plate.trim()) {
      setError("Please enter a license plate.");
      return;
    }

    try {
      const response = await axios.post(
        `${API}/api/parking/check-in`,
        {
          garage_id: garage.id,
          license_plate: plate.trim().toUpperCase(),
          vehicle_type: vehicleType,
        }
      );

      setMessage(
        `Vehicle checked in successfully. Spot ${response.data.spot} assigned.`
      );

      setPlate("");

      await loadDashboard();
    } catch (err) {
      setError(
        err.response?.data?.detail ||
          "Check-in failed."
      );
    }
  };

  // -----------------------------
  // Check Out
  // -----------------------------

  const checkOut = async () => {
    clearMessages();
    setCheckoutResult(null);

    if (!plate.trim()) {
      setError("Please enter a license plate.");
      return;
    }

    try {
      const response = await axios.post(
        `${API}/api/parking/check-out`,
        {
          license_plate: plate.trim().toUpperCase(),
        }
      );

      setCheckoutResult(response.data);
      setMessage("Vehicle checked out successfully.");

      setPlate("");

      await loadDashboard();
    } catch (err) {
      setError(
        err.response?.data?.detail ||
          "Vehicle not found."
      );
    }
  };

  // -----------------------------
  // Records
  // -----------------------------

  const loadRecords = async (requestedPage = 1) => {
    clearMessages();

    try {
      const response = await axios.get(
        `${API}/api/parking/sessions`,
        {
          params: {
            page: requestedPage,
            limit: 8,
            search: search,
            sort_by: sortBy,
            order: order,
          },
        }
      );

      const data = response.data;

      setRecords(data.data || []);
      setRecordPage(data.page || requestedPage);
      setRecordPages(data.pages || 1);
    } catch (err) {
      setError(
        err.response?.data?.detail ||
          "Unable to load parking records."
      );
    }
  };

  // -----------------------------
  // Landing Page
  // -----------------------------

  if (!loggedIn && page === "landing") {
    return (
      <div className="landing">

        <header className="landing-nav">
          <div className="brand">
            <div className="brand-icon">P</div>
            <span>SmartPark</span>
          </div>

          <div className="nav-actions">
            <button
              className="text-button"
              onClick={() => setPage("login")}
            >
              Sign in
            </button>

            <button
              className="dark-button small-button"
              onClick={() => setPage("register")}
            >
              Get started
            </button>
          </div>
        </header>

        <section className="hero">

          <div className="hero-content">

            <div className="eyebrow">
              PARKING MANAGEMENT, SIMPLIFIED
            </div>

            <h1>
              Smarter parking.
              <br />
              <span>Zero parking chaos.</span>
            </h1>

            <p>
              A simple platform for parking attendants
              to manage vehicles, parking spaces and
              accurate billing in real time.
            </p>

            <div className="hero-actions">

              <button
                className="dark-button"
                onClick={() => setPage("login")}
              >
                Open dashboard →
              </button>

              <button
                className="outline-button"
                onClick={() => setPage("register")}
              >
                Create account
              </button>

            </div>

          </div>

          <div className="hero-card">

            <div className="mini-header">
              <span>Garage overview</span>
              <span className="online">● Live</span>
            </div>

            <div className="mini-stats">

              <div>
                <strong>
                  {spots.length || "20"}
                </strong>
                <span>Total spots</span>
              </div>

              <div>
                <strong>
                  {spots.filter((s) => !s.is_occupied).length || "18"}
                </strong>
                <span>Available</span>
              </div>

              <div>
                <strong>
                  {spots.filter((s) => s.is_occupied).length || "2"}
                </strong>
                <span>Occupied</span>
              </div>

            </div>

            <div className="mini-parking">

              {[1, 2, 3, 4, 5, 6].map((item) => (
                <div
                  key={item}
                  className={
                    item === 3
                      ? "mini-spot busy"
                      : "mini-spot"
                  }
                >
                  {item < 6 ? "A-0" + item : "EV-01"}
                </div>
              ))}

            </div>

          </div>

        </section>

        <section className="features">

          <div className="section-label">
            EVERYTHING AN ATTENDANT NEEDS
          </div>

          <div className="feature-grid">

            <div className="feature">
              <div className="feature-number">01</div>
              <h3>Fast check-in</h3>
              <p>
                Quickly assign the correct parking
                spot when a vehicle arrives.
              </p>
            </div>

            <div className="feature">
              <div className="feature-number">02</div>
              <h3>Accurate billing</h3>
              <p>
                Tiered hourly rates, rounded hours
                and daily caps are calculated automatically.
              </p>
            </div>

            <div className="feature">
              <div className="feature-number">03</div>
              <h3>EV ready</h3>
              <p>
                EV vehicles are automatically restricted
                to available charging spots.
              </p>
            </div>

          </div>

        </section>

        <section className="audience">

          <div>
            <div className="section-label">
              BUILT FOR REAL GARAGES
            </div>

            <h2>
              Less paperwork.
              <br />
              Better operations.
            </h2>
          </div>

          <p>
            SmartPark gives attendants one place to
            manage active vehicles, monitor capacity,
            find parking records and generate the
            correct fee at checkout.
          </p>

        </section>

        <section className="next-section">

          <div className="section-label">
            WHAT COMES NEXT
          </div>

          <div className="next-grid">

            <div>Online payments</div>
            <div>Mobile attendant app</div>
            <div>Revenue analytics</div>

          </div>

        </section>

        <footer>
          <strong>SmartPark</strong>
          <span>Parking management made simple.</span>
        </footer>

      </div>
    );
  }

  // -----------------------------
  // Login
  // -----------------------------

  if (!loggedIn && page === "login") {
    return (
      <div className="auth-page">

        <div className="auth-card">

          <button
            className="back-button"
            onClick={() => {
              clearMessages();
              setPage("landing");
            }}
          >
            ← Back
          </button>

          <div className="brand auth-brand">
            <div className="brand-icon">P</div>
            <span>SmartPark</span>
          </div>

          <h1>Welcome back</h1>

          <p className="muted">
            Sign in to manage your garage.
          </p>

          <label>Email</label>

          <input
            type="email"
            value={email}
            onChange={(e) =>
              setEmail(e.target.value)
            }
            placeholder="you@example.com"
          />

          <label>Password</label>

          <input
            type="password"
            value={password}
            onChange={(e) =>
              setPassword(e.target.value)
            }
            placeholder="••••••••"
          />

          {error && (
            <div className="error">{error}</div>
          )}

          <button
            className="dark-button full-button"
            onClick={login}
          >
            Sign in
          </button>

          <p className="auth-switch">
            Don't have an account?{" "}
            <button
              onClick={() => {
                clearMessages();
                setPage("register");
              }}
            >
              Create one
            </button>
          </p>

        </div>

      </div>
    );
  }

  // -----------------------------
  // Register
  // -----------------------------

  if (!loggedIn && page === "register") {
    return (
      <div className="auth-page">

        <div className="auth-card">

          <button
            className="back-button"
            onClick={() => {
              clearMessages();
              setPage("landing");
            }}
          >
            ← Back
          </button>

          <div className="brand auth-brand">
            <div className="brand-icon">P</div>
            <span>SmartPark</span>
          </div>

          <h1>Create account</h1>

          <p className="muted">
            Set up your SmartPark account.
          </p>

          <label>Name</label>

          <input
            value={name}
            onChange={(e) =>
              setName(e.target.value)
            }
            placeholder="Your name"
          />

          <label>Email</label>

          <input
            type="email"
            value={email}
            onChange={(e) =>
              setEmail(e.target.value)
            }
            placeholder="you@example.com"
          />

          <label>Password</label>

          <input
            type="password"
            value={password}
            onChange={(e) =>
              setPassword(e.target.value)
            }
            placeholder="••••••••"
          />

          {error && (
            <div className="error">{error}</div>
          )}

          {message && (
            <div className="success">{message}</div>
          )}

          <button
            className="dark-button full-button"
            onClick={register}
          >
            Create account
          </button>

          <p className="auth-switch">
            Already have an account?{" "}
            <button
              onClick={() => {
                clearMessages();
                setPage("login");
              }}
            >
              Sign in
            </button>
          </p>

        </div>

      </div>
    );
  }

  // -----------------------------
  // Application
  // -----------------------------

  const totalSpots = spots.length;

  const availableSpots = spots.filter(
    (spot) => !spot.is_occupied
  ).length;

  const occupiedSpots = spots.filter(
    (spot) => spot.is_occupied
  ).length;

  const evSpots = spots.filter(
    (spot) => spot.spot_type === "EV"
  );

  const availableEv = evSpots.filter(
    (spot) => !spot.is_occupied
  ).length;

  return (
    <div className="app">

      <header className="topbar">

        <div className="brand">
          <div className="brand-icon">P</div>
          <span>SmartPark</span>
        </div>

        <div className="topbar-right">

          <span className="garage-label">
            {garage?.name || "Parking Garage"}
          </span>

          <button
            className="logout-button"
            onClick={logout}
          >
            Logout
          </button>

        </div>

      </header>

      <div className="app-layout">

        <aside className="sidebar">

          <div className="side-title">
            MANAGEMENT
          </div>

          <button
            className={
              page === "dashboard"
                ? "nav-item active"
                : "nav-item"
            }
            onClick={() => {
              clearMessages();
              setPage("dashboard");
            }}
          >
            <span>⌂</span>
            Dashboard
          </button>

          <button
            className={
              page === "checkin"
                ? "nav-item active"
                : "nav-item"
            }
            onClick={() => {
              clearMessages();
              setPage("checkin");
            }}
          >
            <span>+</span>
            Check In
          </button>

          <button
            className={
              page === "checkout"
                ? "nav-item active"
                : "nav-item"
            }
            onClick={() => {
              clearMessages();
              setCheckoutResult(null);
              setPage("checkout");
            }}
          >
            <span>→</span>
            Check Out
          </button>

          <button
            className={
              page === "records"
                ? "nav-item active"
                : "nav-item"
            }
            onClick={() => {
              clearMessages();
              setPage("records");
              loadRecords(1);
            }}
          >
            <span>≡</span>
            Parking Records
          </button>

          <div className="sidebar-bottom">
            <div className="system-status">
              <span></span>
              System operational
            </div>
          </div>

        </aside>

        <main className="main-content">

          {/* Dashboard */}

          {page === "dashboard" && (
            <>
              <div className="page-header">

                <div>
                  <div className="breadcrumb">
                    OVERVIEW
                  </div>

                  <h1>Dashboard</h1>

                  <p>
                    Monitor your garage in real time.
                  </p>
                </div>

                <button
                  className="dark-button"
                  onClick={() => {
                    clearMessages();
                    setPage("checkin");
                  }}
                >
                  + Check in vehicle
                </button>

              </div>

              {message && (
                <div className="success">
                  {message}
                </div>
              )}

              {error && (
                <div className="error">
                  {error}
                </div>
              )}

              <div className="stats-grid">

                <div className="stat-card">
                  <span>Total spots</span>
                  <strong>{totalSpots}</strong>
                  <small>Garage capacity</small>
                </div>

                <div className="stat-card">
                  <span>Available</span>
                  <strong>{availableSpots}</strong>
                  <small>Ready for vehicles</small>
                </div>

                <div className="stat-card">
                  <span>Occupied</span>
                  <strong>{occupiedSpots}</strong>
                  <small>Currently parked</small>
                </div>

                <div className="stat-card ev-stat">
                  <span>EV available</span>
                  <strong>
                    {availableEv}/{evSpots.length}
                  </strong>
                  <small>Charging spots</small>
                </div>

              </div>

              <div className="content-card">

                <div className="card-header">

                  <div>
                    <h2>Parking spots</h2>
                    <p>
                      Current occupancy across the garage.
                    </p>
                  </div>

                  <span className="live-status">
                    ● Live
                  </span>

                </div>

                <div className="spot-grid">

                  {spots.map((spot) => (
                    <div
                      key={spot.id}
                      className={
                        spot.is_occupied
                          ? "spot-card occupied"
                          : "spot-card available"
                      }
                    >

                      <div className="spot-top">
                        <strong>
                          {spot.spot_number}
                        </strong>

                        <span>
                          {spot.spot_type}
                        </span>
                      </div>

                      <div className="spot-bottom">
                        {spot.is_occupied
                          ? "Occupied"
                          : "Available"}
                      </div>

                    </div>
                  ))}

                </div>

              </div>
            </>
          )}

          {/* Check In */}

          {page === "checkin" && (
            <div className="form-container">

              <div className="page-header">
                <div>
                  <div className="breadcrumb">
                    PARKING
                  </div>

                  <h1>Check in vehicle</h1>

                  <p>
                    Register an arriving vehicle.
                  </p>
                </div>
              </div>

              <div className="form-card">

                <label>License plate</label>

                <input
                  value={plate}
                  onChange={(e) =>
                    setPlate(
                      e.target.value.toUpperCase()
                    )
                  }
                  placeholder="RJ14AB1234"
                />

                <label>Vehicle type</label>

                <select
                  value={vehicleType}
                  onChange={(e) =>
                    setVehicleType(e.target.value)
                  }
                >
                  <option value="COMPACT">
                    Compact
                  </option>

                  <option value="STANDARD">
                    Standard
                  </option>

                  <option value="EV">
                    EV
                  </option>
                </select>

                {vehicleType === "EV" && (
                  <div className="info-box">
                    EV vehicles can only use EV
                    charging spots.
                  </div>
                )}

                {error && (
                  <div className="error">
                    {error}
                  </div>
                )}

                {message && (
                  <div className="success">
                    {message}
                  </div>
                )}

                <button
                  className="dark-button full-button"
                  onClick={checkIn}
                >
                  Confirm check in
                </button>

              </div>

            </div>
          )}

          {/* Check Out */}

          {page === "checkout" && (
            <div className="form-container">

              <div className="page-header">
                <div>
                  <div className="breadcrumb">
                    PARKING
                  </div>

                  <h1>Check out vehicle</h1>

                  <p>
                    Complete the parking session and
                    calculate the final fee.
                  </p>
                </div>
              </div>

              <div className="form-card">

                <label>License plate</label>

                <input
                  value={plate}
                  onChange={(e) =>
                    setPlate(
                      e.target.value.toUpperCase()
                    )
                  }
                  placeholder="RJ14AB1234"
                />

                {error && (
                  <div className="error">
                    {error}
                  </div>
                )}

                <button
                  className="dark-button full-button"
                  onClick={checkOut}
                >
                  Complete check out
                </button>

              </div>

              {checkoutResult && (
                <div className="receipt">

                  <div className="receipt-head">
                    <div>
                      <span>SMARTPARK</span>
                      <h2>Parking receipt</h2>
                    </div>

                    <div className="paid">
                      ✓ Completed
                    </div>
                  </div>

                  <div className="receipt-row">
                    <span>License plate</span>
                    <strong>
                      {checkoutResult.license_plate}
                    </strong>
                  </div>

                  <div className="receipt-row">
                    <span>Parking spot</span>
                    <strong>
                      {checkoutResult.spot}
                    </strong>
                  </div>

                  <div className="receipt-row">
                    <span>Billable hours</span>
                    <strong>
                      {checkoutResult.billable_hours}
                    </strong>
                  </div>

                  <div className="receipt-total">
                    <span>Total fee</span>
                    <strong>
                      ₹{checkoutResult.fee}
                    </strong>
                  </div>

                </div>
              )}

            </div>
          )}

          {/* Records */}

          {page === "records" && (
            <div>

              <div className="page-header">

                <div>
                  <div className="breadcrumb">
                    MANAGEMENT
                  </div>

                  <h1>Parking records</h1>

                  <p>
                    Search, sort and review parking history.
                  </p>
                </div>

              </div>

              <div className="filter-bar">

                <input
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                  placeholder="Search license plate..."
                />

                <select
                  value={sortBy}
                  onChange={(e) =>
                    setSortBy(e.target.value)
                  }
                >
                  <option value="check_in">
                    Check-in
                  </option>

                  <option value="check_out">
                    Check-out
                  </option>

                  <option value="fee">
                    Fee
                  </option>

                  <option value="license_plate">
                    License plate
                  </option>

                  <option value="status">
                    Status
                  </option>
                </select>

                <select
                  value={order}
                  onChange={(e) =>
                    setOrder(e.target.value)
                  }
                >
                  <option value="desc">
                    Newest
                  </option>

                  <option value="asc">
                    Oldest
                  </option>
                </select>

                <button
                  className="dark-button"
                  onClick={() => loadRecords(1)}
                >
                  Search
                </button>

              </div>

              {error && (
                <div className="error">
                  {error}
                </div>
              )}

              <div className="table-card">

                <table>

                  <thead>
                    <tr>
                      <th>License plate</th>
                      <th>Vehicle</th>
                      <th>Spot</th>
                      <th>Check-in</th>
                      <th>Check-out</th>
                      <th>Fee</th>
                      <th>Status</th>
                    </tr>
                  </thead>

                  <tbody>

                    {records.map((record) => (
                      <tr key={record.id}>

                        <td>
                          <strong>
                            {record.license_plate}
                          </strong>
                        </td>

                        <td>
                          {record.vehicle_type}
                        </td>

                        <td>
                          #{record.spot_id}
                        </td>

                        <td>
                          {record.check_in
                            ? new Date(
                                record.check_in
                              ).toLocaleString()
                            : "-"}
                        </td>

                        <td>
                          {record.check_out
                            ? new Date(
                                record.check_out
                              ).toLocaleString()
                            : "-"}
                        </td>

                        <td>
                          {record.fee !== null &&
                          record.fee !== undefined
                            ? `₹${record.fee}`
                            : "-"}
                        </td>

                        <td>
                          <span
                            className={
                              record.status === "PARKED"
                                ? "status parked"
                                : "status completed"
                            }
                          >
                            {record.status}
                          </span>
                        </td>

                      </tr>
                    ))}

                  </tbody>

                </table>

                {records.length === 0 && (
                  <div className="empty">
                    No parking records found.
                  </div>
                )}

              </div>

              <div className="pagination">

                <button
                  disabled={recordPage <= 1}
                  onClick={() =>
                    loadRecords(recordPage - 1)
                  }
                >
                  ← Previous
                </button>

                <span>
                  Page {recordPage} of {recordPages}
                </span>

                <button
                  disabled={
                    recordPage >= recordPages
                  }
                  onClick={() =>
                    loadRecords(recordPage + 1)
                  }
                >
                  Next →
                </button>

              </div>

            </div>
          )}

        </main>

      </div>

    </div>
  );
}

export default App;